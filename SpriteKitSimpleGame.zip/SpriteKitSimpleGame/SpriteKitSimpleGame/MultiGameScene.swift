//
//  MultiGameScene.swift
//  SpriteKitSimpleGame
//
//  Created by Jimit Upadhyay on 2017-10-05.
//  Copyright © 2017 Jimit Upadhyay. All rights reserved.
//

import Foundation
import SpriteKit

class MultiMenuScene: SKScene {
    var play1Button = SKSpriteNode()
    var play2Button = SKSpriteNode()
   
    let play1ButtonTex = SKTexture(imageNamed: "play1")
    let play2ButtonTex = SKTexture(imageNamed: "play2")
   
    override func didMove(to view: SKView) {
        backgroundColor = SKColor.white
        play1Button = SKSpriteNode(texture: play1ButtonTex)
        play1Button.position = CGPoint(x:  size.width * 0.2, y: frame.midY)
        play1Button.size = CGSize(width: 300, height: 100)
        
        play2Button = SKSpriteNode(texture: play2ButtonTex)
        play2Button.position = CGPoint(x: (frame.maxX - size.width + frame.midX + (frame.midX/2))  , y: frame.midY)
        play2Button.size = CGSize(width: 300, height: 100)
        self.addChild(play1Button)
        self.addChild(play2Button)
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let pos = touch.location(in: self)
            let node = self.atPoint(pos)
            
            if node == play1Button {
                if let view = view {
                    let defaults = UserDefaults.standard
                    defaults.set(2, forKey: "user")
                    
                    defaults.synchronize()
                    let transition:SKTransition = SKTransition.fade(withDuration: 1)
                    let scene:SKScene = SpeedGameScene(size: self.size)
                    self.view?.presentScene(scene, transition: transition)
                }
            }
            if node == play2Button {
                
                let defaults = UserDefaults.standard
                defaults.set(3, forKey: "user")
                
                defaults.synchronize()
                let transition:SKTransition = SKTransition.fade(withDuration: 1)
                let scene:SKScene = SpeedGameScene(size: self.size)
                self.view?.presentScene(scene, transition: transition)
                
            }
            
        }
    }
}
