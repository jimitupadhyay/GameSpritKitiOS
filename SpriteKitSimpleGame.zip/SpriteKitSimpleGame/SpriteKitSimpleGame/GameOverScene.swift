//
//  GameOverScene.swift
//  SpriteKitSimpleGame
//
//  Created by Jimit Upadhyay on 2017-09-28.
//  Copyright © 2017 Jimit Upadhyay. All rights reserved.
//

import Foundation

import SpriteKit

class GameOverScene: SKScene {
    
    init(size: CGSize, won:Bool) {
        
        super.init(size: size)
        
        // 1
        backgroundColor = SKColor.white
        
        
        // 2
        let defaults = UserDefaults.standard
        
        var score = 0
        score = defaults.integer(forKey: "scoreKey")
        print(score)
        let defaults1 = UserDefaults.standard
        let score1 = defaults1.integer(forKey: "user")
        print(score1)
        if(score1 == 2){
        let message = won ? "You Won! User 1 Score is :\(score)" : "You Lose User 1 :[  Score is :\(score)"
            
            let label = SKLabelNode(fontNamed: "Chalkduster")
            label.text = message
            label.fontSize = 40
            label.fontColor = SKColor.black
            label.position = CGPoint(x: size.width/2, y: size.height/2)
            addChild(label)
            
            score = 0
            
        }
       if(score1 == 3){
            
            let message = won ? "You Won! User 2 Score is :\(score)" : "You Lose User 2 :[  Score is :\(score)"
            
            let label = SKLabelNode(fontNamed: "Chalkduster")
            label.text = message
            label.fontSize = 40
            label.fontColor = SKColor.black
            label.position = CGPoint(x: size.width/2, y: size.height/2)
            addChild(label)
            score = 0
        }
        if(score1 == 1){
        
            let message = won ? "You Won! Score is :\(score)" : "You Lose :[  Score is :\(score)"
            
            let label = SKLabelNode(fontNamed: "Chalkduster")
            label.text = message
            label.fontSize = 40
            label.fontColor = SKColor.black
            label.position = CGPoint(x: size.width/2, y: size.height/2)
            addChild(label)
            score = 0
            
        }
        // 3
       
        
        // 4
        run(SKAction.sequence([
            SKAction.wait(forDuration: 3.0),
            SKAction.run() {
                // 5
                let reveal = SKTransition.flipHorizontal(withDuration: 0.5)
                let scene = MenuScene(size: size)
                self.view?.presentScene(scene, transition:reveal)
            }
            ]))
        
    }
    
    // 6
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
class RecordSave {

    var score = 0;
    
    
    
}
