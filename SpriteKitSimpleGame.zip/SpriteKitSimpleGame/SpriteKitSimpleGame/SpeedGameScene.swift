//
//  SpeedGameScene.swift
//  SpriteKitSimpleGame
//
//  Created by Jimit Upadhyay on 2017-10-05.
//  Copyright © 2017 Jimit Upadhyay. All rights reserved.
//

import Foundation
import SpriteKit

class SpeedGameScene: SKScene {
    
    var speed1Button = SKSpriteNode()
    var speed2Button = SKSpriteNode()
   
    let speed1ButtonTex = SKTexture(imageNamed: "s")
    let speed2ButtonTex = SKTexture(imageNamed: "s2")
    
    override func didMove(to view: SKView) {
        
        speed1Button = SKSpriteNode(texture: speed1ButtonTex)
        speed1Button.position = CGPoint(x:  size.width * 0.2, y: frame.midY)
        speed1Button.size = CGSize(width: 300, height: 100)
        
        speed2Button = SKSpriteNode(texture: speed2ButtonTex)
        speed2Button.position = CGPoint(x: (frame.maxX - size.width + frame.midX + (frame.midX/2))  , y: frame.midY)
        speed2Button.size = CGSize(width: 300, height: 100)
        self.addChild(speed1Button)
        // self.addChild(scoreButton)
        self.addChild(speed2Button)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let pos = touch.location(in: self)
            let node = self.atPoint(pos)
            
            if node == speed1Button {
                if let view = view {
                    let defaults = UserDefaults.standard
                    defaults.set(10, forKey: "speed")
                    
                    defaults.synchronize()
                    let transition:SKTransition = SKTransition.fade(withDuration: 1)
                    let scene:SKScene = GameScene(size: self.size)
                    self.view?.presentScene(scene, transition: transition)
                }
            }
            
            if node == speed2Button {
                
                
                let defaults = UserDefaults.standard
                defaults.set(30, forKey: "speed")
                
                defaults.synchronize()
                print("Multiplayer Game")
                let transition:SKTransition = SKTransition.fade(withDuration: 1)
                let scene:SKScene = GameScene(size: self.size)
                self.view?.presentScene(scene, transition: transition)
                
            }
        }
    }
}
