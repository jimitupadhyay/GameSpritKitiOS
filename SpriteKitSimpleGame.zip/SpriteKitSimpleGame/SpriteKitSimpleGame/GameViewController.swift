//
//  GameViewController.swift
//  SpriteKitSimpleGame
//
//  Created by Jimit Upadhyay on 2017-09-28.
//  Copyright © 2017 Jimit Upadhyay. All rights reserved.
//

import UIKit
import SpriteKit

class GameViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       
        let scene = MenuScene(size : view.bounds.size)
        
        let skview = view as! SKView
        
        skview.showsFPS = true
        
        skview.showsNodeCount = true
        
        skview.ignoresSiblingOrder = true
        
        scene.scaleMode = .resizeFill
        
        skview.presentScene(scene)
        
           }

  
    override var prefersStatusBarHidden: Bool {
        return true
    }
}
