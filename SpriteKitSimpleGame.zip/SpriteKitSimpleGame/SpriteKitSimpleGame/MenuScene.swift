//
//  MenuScene.swift
//  SpriteKitSimpleGame
//
//  Created by Jimit Upadhyay on 2017-10-03.
//  Copyright © 2017 Jimit Upadhyay. All rights reserved.
//

import Foundation
import SpriteKit

class MenuScene: SKScene {
    
    var playButton = SKSpriteNode()
    var scoreButton = SKSpriteNode()
    var multiButton = SKSpriteNode()
    let playButtonTex = SKTexture(imageNamed: "play")
    let scoreButtonTex = SKTexture(imageNamed: "Score_logo")
    let multiButtonTex = SKTexture(imageNamed: "multi_player")
    
    override func didMove(to view: SKView) {
        
        playButton = SKSpriteNode(texture: playButtonTex)
        playButton.position = CGPoint(x:  size.width * 0.2, y: frame.midY)
        playButton.size = CGSize(width: 300, height: 100)
        scoreButton = SKSpriteNode(texture: scoreButtonTex)
        scoreButton.position = CGPoint(x: frame.midX, y:    frame.minY + 50)
        scoreButton.size = CGSize(width: 300, height: 100)
        multiButton = SKSpriteNode(texture: multiButtonTex)
        multiButton.position = CGPoint(x: (frame.maxX - size.width + frame.midX + (frame.midX/2))  , y: frame.midY)
        multiButton.size = CGSize(width: 300, height: 100)
        self.addChild(playButton)
       // self.addChild(scoreButton)
        self.addChild(multiButton)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let pos = touch.location(in: self)
            let node = self.atPoint(pos)
            
            if node == playButton {
                if let view = view {
                    let defaults = UserDefaults.standard
                    defaults.set(1, forKey: "user")
                    
                    defaults.synchronize()
                    let transition:SKTransition = SKTransition.fade(withDuration: 1)
                    let scene:SKScene = SpeedGameScene(size: self.size)
                    self.view?.presentScene(scene, transition: transition)
                }
            }
             if node == scoreButton {
         
                print("score")
            
            }
            if node == multiButton {
                
                print("Multiplayer Game")
                let transition:SKTransition = SKTransition.fade(withDuration: 1)
                let scene:SKScene = MultiMenuScene(size: self.size)
                self.view?.presentScene(scene, transition: transition)
                
            }
        }
    }
}
